package config;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.testng.Assert;
import config.ObjectRepository;

public class Keywords extends BasePage{
	  //*********Constructor*********
public Keywords(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }


//*********Page Methods*********
//@Step("Login Step with username: {0}, password: {1}, for method: {method} step...")
public void Login (XSSFRow row){
    //Enter User
    writeText(By.name(ObjectRepository.input_username),row.getCell(1).toString());
    //Enter Password
    writeText(By.name(ObjectRepository.input_password), row.getCell(2).toString());
    //Click Login Button
    click(By.name(ObjectRepository.btn_login));
}

//Verify User Condition (that username is required)
//@Step("Verify username: {0} step...")
public void verifyLoginUserName (String expectedUserNameMessage) {
    Assert.assertEquals(readText(By.id(ObjectRepository.errorMessageUsername)), expectedUserNameMessage);
}

//Verify Password Condition. (that password is required)
//@Step("Verify verifyLoginPassword: {0} step...")
public void verifyLoginPassword (String expectedPasswordMessage) {
    Assert.assertEquals(readText(By.id(ObjectRepository.errorMessagePassword)), expectedPasswordMessage);
}

//Verify Invalid Credentials Condition
//@Step("Verify verifyLoginPassword: {0} step...")
public void verifyLoginCredentials (String expectedCredentialsMessage) {
  Assert.assertEquals(readText(By.xpath(ObjectRepository.errorMessageCredentials)), expectedCredentialsMessage);
}

public void VerifyBooking(XSSFRow row) {
	//click on book appointments link
	click(By.xpath(ObjectRepository.bookLink));
	click(By.name(ObjectRepository.dpdDoctorSpec));
	click(By.xpath(ObjectRepository.doctorSpecOption));
	click(By.name(ObjectRepository.dpdDoctor));
	click(By.xpath(ObjectRepository.doctorOption));
	writeText(By.name(ObjectRepository.pickerDate),row.getCell(1).toString());
	writeText(By.name(ObjectRepository.pickerTime),row.getCell(2).toString());
	click(By.name(ObjectRepository.btnSubmit));
}

}
