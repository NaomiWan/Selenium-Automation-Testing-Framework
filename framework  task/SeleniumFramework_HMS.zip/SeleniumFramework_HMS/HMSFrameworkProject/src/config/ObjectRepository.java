package config;


public class ObjectRepository {
	
//Home Page Objects
public static String link_patients="//a[@href='hms/user-login.php']";

//login page objects
static String input_username="username";
static String input_password="password";
static String btn_login="submit";

//appointments page objects
static String lnkBookAppointment= "//a[@href='book-appointment.php']";

//book appointment page objects
static String bookLink= "//*[@id='container']/div/div/div[3]/div/div/p/a";
static String dpdDoctorSpec= "Doctorspecialization";
static String doctorSpecOption="//*[@id='container']/div/div/div/div/div/div/div[2]/form/div[1]/select/option[3]";
static String dpdDoctor="doctor";
static String doctorOption="//*[@id='doctor']/option[2]";
static String pickerDate="appdate";
static String pickerTime="apptime";
static String btnSubmit="submit";


static String errorMessageUsername = "username-error";
static String errorMessagePassword = "password-error";
static String errorMessageCredentials = "/html/body/div/div/div[2]/form/fieldset/p/span";
}
