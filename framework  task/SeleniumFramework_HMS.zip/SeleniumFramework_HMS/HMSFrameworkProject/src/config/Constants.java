package config;

public class Constants {

	//system variables
	public static final String URL = "http://asthmaticguide.com/hospital/";
	public static final String chromedriverpath = "D:\\SeleniumTools\\SeleniumTestsDrivers\\chromedriver.exe";
	public static final String geckodriverpath = "D:\\SeleniumTools\\SeleniumTestsDrivers\\geckodriver.exe";
	public static final String iedriverpath = "D:\\SeleniumTools\\SeleniumTestsDrivers\\IEDriverServer.exe";



}

