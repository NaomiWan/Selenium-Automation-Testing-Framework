package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import config.Keywords;
import utils.excelutils.ExcelUtil;

public class TestsDriver extends BaseTest {

    @BeforeTest
    public void setupTestData () {
        //Set Test Data Excel and Sheet
        System.out.println("************Setup Test Level Data**********");
        ExcelUtil.setExcelFileSheet("LoginData");
    }

    @Test (priority = 0)
    public void LoginTest_InvalidUserNameInvalidPassword () throws InterruptedException {

    	//*************PAGE INSTANTIATIONS*************
        Keywords keyword = new Keywords(driver,wait);
        
        //*************PAGE METHODS********************
       //Login to N11 with first row of the login data
        keyword.Login(ExcelUtil.getRowData(1));

        //Set test row number to 1
        ExcelUtil.setRowNumber(1);
        
        //Set Test Status column number to 5
        ExcelUtil.setColumnNumber(5);
        
        //*************ASSERTIONS***********************
        Thread.sleep(500);
        //Verify password message by using excel's 2nd row, 5th column
        //Row and Column numbers starting from 0. Thus we need to write 1 and 4, instead of 2 and 5!
        keyword.verifyLoginCredentials(ExcelUtil.getCellData(1,4));
      
        //Record test outcome.
        ExcelUtil.setCellData("Pass", 1, 5);

    }

    @Test (priority = 1)
    public void LoginTest_EmptyUserEmptyPassword () throws InterruptedException {
   
        //*************PAGE INSTANTIATIONS*************
        Keywords keyword = new Keywords(driver,wait);

        //*************PAGE METHODS********************
        //Login to N11 with second row of the login data
        keyword.Login(ExcelUtil.getRowData(2));

        //Set test row number to 2
        ExcelUtil.setRowNumber(2);

        //Set Test Status column number to 5
        ExcelUtil.setColumnNumber(5);

        //*************ASSERTIONS***********************
        Thread.sleep(500);
        //Verify by 3rd row and 4th column
        keyword.verifyLoginUserName(ExcelUtil.getCellData(2,3));
        //Verify by 3rd row and 5th column
        keyword.verifyLoginPassword(ExcelUtil.getCellData(2,4));
        
        //Record test outcome.
        ExcelUtil.setCellData("Pass", 2, 5);
    }
    
    @Test (priority = 2)
    public void LoginTest() throws InterruptedException {
   
        //*************PAGE INSTANTIATIONS*************
        Keywords keyword = new Keywords(driver,wait);

        //*************PAGE METHODS********************
        //Login to N11 with second row of the login data
        keyword.Login(ExcelUtil.getRowData(3));

        //Set test row number to 2
        ExcelUtil.setRowNumber(2);

        //Set Test Status column number to 5
        ExcelUtil.setColumnNumber(5);

        //*************ASSERTIONS***********************
        Thread.sleep(500);
        //Verify by 3rd row and 4th column
        //Record test outcome.
        ExcelUtil.setCellData("Pass", 3, 5);
    }
    
    @Test (priority = 3)
	 public void bookAppointment() throws InterruptedException {
		 
	 	 ExcelUtil.setExcelFileSheet("BookAppointment");
	 	//*************PAGE INSTANTIATIONS*************
	     Keywords keyword = new Keywords(driver,wait);

	     //*************PAGE METHODS********************
	     //Book appointment with second row of the booking data
	    
	     keyword.VerifyBooking(ExcelUtil.getRowData(1));
	     //Set test row number to 1
	     ExcelUtil.setRowNumber(1);

	     //Set Test Status column number to 3
	     ExcelUtil.setColumnNumber(3);

	     //*************ASSERTIONS***********************
	     Thread.sleep(500);
	     //Verify by 3rd row and 4th column
	   //  keyword.VerifyBooking(ExcelUtil.getCellData(1,1));
	     //Verify by 3rd row and 5th column
	    // keyword.verifyLoginPassword(ExcelUtil.getCellData(2,4));
	     
	     //Record test outcome.
	     //ExcelUtil.setCellData("Pass", 1, 3);
	 }
}

