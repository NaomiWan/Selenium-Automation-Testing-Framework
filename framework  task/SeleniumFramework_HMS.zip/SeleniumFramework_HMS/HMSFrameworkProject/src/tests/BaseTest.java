package tests;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import config.Constants;
import config.ObjectRepository;

public class BaseTest {
    public WebDriver driver;
    public WebDriverWait wait;
    //Global test data excel file
    public static final String testDataExcelFileName = "testdata.xlsx";


    public WebDriver getDriver() {
        return driver;
    }


    @BeforeClass (description = "Class Level Setup!")
    public void setup () {
        //Create a Chrome driver instance to be used by all test classes use this.
    	File file = new File(Constants.geckodriverpath);
    	System.setProperty("webdriver.gecko.driver", file.getAbsolutePath());
		driver = new FirefoxDriver();
    	
    	//File file = new File(Constants.chromedriverpath);
		//System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
    	//driver = new ChromeDriver();
    	
    	//File file = new File(Constants.iedriverpath);
    	//System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
    	//driver = new InternetExplorerDriver();

        //Maximize Window
        driver.manage().window().maximize();
    	driver.get(Constants.URL);
    	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    	((JavascriptExecutor)driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
    	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    	driver.findElement(By.xpath(ObjectRepository.link_patients)).click();	
    	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    @AfterClass(description = "Class Level Teardown!")
    public void teardown () {
        driver.quit();
    }

}
